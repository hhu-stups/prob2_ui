#!/bin/bash
zip -r Blinking_Portable.zip html_files Blinking.pdf

